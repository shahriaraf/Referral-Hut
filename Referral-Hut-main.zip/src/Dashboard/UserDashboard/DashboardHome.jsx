import React from 'react';

const DashboardHome = () => {
    return (
        <div>
            <h1> this is dahsboarde home</h1>
        </div>
    );
};

export default DashboardHome;